﻿// .h include
#include "%classname%.h"

// Qt lib import
#include <QDebug>
