﻿#if defined __cplusplus

#include <iostream>
#include <functional>
#include <algorithm>
#include <memory>
#include <initializer_list>

#include <QApplication>
#include <QVariant>
#include <QMap>
#include <QList>
#include <QVector>
#include <QStringList>
#include <QDir>
#include <QPointer>
#include <QColor>
#include <QStandardPaths>
#include <QSharedPointer>
#include <QWeakPointer>
#include <QPointer>
#include <QDateTime>
#include <QTimer>
#include <QDebug>
#include <QImage>
#include <QJsonObject>
#include <QJsonArray>
#include <QJsonDocument>
#include <QEventLoop>
#include <QMutex>
#include <QSemaphore>
#include <QUrl>
#include <QFile>
#include <QFileInfo>
#include <QPair>
#include <QThread>
#include <QMetaObject>

#endif
